package com.company.servlet;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import jakarta.servlet.http.HttpSession;

import java.io.IOException;

import com.company.dao.UserDao;
import com.company.dao.UserDaoImpl;

public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    private static UserDao uesrDao= new UserDaoImpl();  
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginServlet() {
        super();
        // TODO Auto-generated constructor stub
    }
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		        String email = request.getParameter("email");
		        String password = request.getParameter("password");
		        HttpSession session = request.getSession();
		        if("admin@gmail.com".equals(email) && "admin".equals(password))
		        {
		        	System.out.println("got admin as user");
		        	session.setAttribute("email", email);
		        	response.sendRedirect("admin/adminHome.jsp");
		        }
		        else if(uesrDao.isValidUser(email, password)) {
		        	session.setAttribute("email", email);
		        	response.sendRedirect("home.jsp");
		        	}

		        else {
		            response.sendRedirect("login.jsp?error=1");
		        	System.out.println("Error occured");
		        }
	}
	}

